# Programa 2: verificar triangulo e calcular sua area
import math

a = int(input("Digite o primeiro lado: "))
b = int(input("Digite o segundo lado: "))
c = int(input("Digite o terceiro lado: "))

if a <= 0 or b <= 0 or c <= 0:
    print("Os valores devem ser inteiros positivos.")
elif a + b > c and a + c > b and b + c > a:
    semiperimetro = (a + b + c) / 2
    area = math.sqrt(semiperimetro * (semiperimetro - a) *
                     (semiperimetro - b) * (semiperimetro - c))
    print(f"Os valores formam um triangulo. Area: {area:.2f}")
else:
    print(f"Os valores {a}, {b} e {c} nao formam um triangulo.")
