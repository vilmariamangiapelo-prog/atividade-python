# Atividade de Programacao em Python

Este repositorio contem os cinco programas solicitados.

1. `01_idade_em_anos_meses_dias.py` - converte dias em anos, meses e dias (ano de 365 dias e mes de 30 dias, como aproximacao).
2. `02_verificar_triangulo_e_area.py` - verifica os lados e calcula a area pela formula de Heron.
3. `03_menor_de_tres_numeros.py` - mostra o menor de tres inteiros.
4. `04_numeros_primos_de_1_a_100.py` - verifica numeros primos e testa de 1 a 100.
5. `05_inverter_letras_de_cada_palavra.py` - inverte as letras de cada palavra da frase.

Para executar um programa, abra o terminal nesta pasta e digite, por exemplo:
`python 01_idade_em_anos_meses_dias.py`
