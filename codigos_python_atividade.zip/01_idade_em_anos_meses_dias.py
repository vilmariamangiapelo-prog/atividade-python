# Programa 1: converter idade em dias para anos, meses e dias
idade_dias = int(input("Digite a idade em dias: "))

anos = idade_dias // 365
resto = idade_dias % 365
meses = resto // 30
dias = resto % 30

print(f"Idade: {anos} ano(s), {meses} mes(es) e {dias} dia(s).")
