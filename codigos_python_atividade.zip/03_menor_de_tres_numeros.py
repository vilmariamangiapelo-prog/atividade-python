# Programa 3: encontrar o menor de tres numeros inteiros
a = int(input("Digite o primeiro numero: "))
b = int(input("Digite o segundo numero: "))
c = int(input("Digite o terceiro numero: "))

menor = min(a, b, c)
print(f"O menor numero e: {menor}")
